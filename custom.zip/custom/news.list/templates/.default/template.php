<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

// получим путь к папке вида /bitrix/components/custom/news.list/templates/.default
$folder_path = str_replace(realpath($_SERVER["DOCUMENT_ROOT"]), '', dirname(__FILE__));
$file_path = $folder_path . '/build/';

// var_dump($arResult);
require_once 'build/index.html';

// $this->addExternalCss("/local/components/custom/news.list/templates/.default/build/css/common.css");

?>